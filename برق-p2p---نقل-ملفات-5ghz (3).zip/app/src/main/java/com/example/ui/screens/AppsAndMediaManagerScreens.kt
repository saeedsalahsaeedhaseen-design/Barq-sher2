package com.example.ui.screens

import android.Manifest
import android.net.Uri
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.CheckBox
import androidx.compose.material.icons.filled.CheckBoxOutlineBlank
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DeviceMediaItem
import com.example.model.FileCategory
import com.example.model.FileTransferStatus
import com.example.model.FilesSubTab
import com.example.model.InstalledAppItem
import com.example.model.SortOption
import com.example.model.TransferDirection
import com.example.model.TransferHistoryRecord
import com.example.ui.components.CopyrightFooter
import com.example.ui.components.SelectionBottomActionBar
import com.example.ui.components.categoryIcon
import com.example.ui.components.formatBytesArabic
import com.example.ui.components.formatDurationArabic
import com.example.ui.components.formatSpeedArabic
import com.example.ui.theme.CoralRose
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.HotspotAmber
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MidnightCard
import com.example.ui.theme.MidnightSurface
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.P2PUiState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Section 3: Installed Applications Screen showing real colored app icons, app name,
 * package name, actual APK size, split APK warnings, search, and multi-selection.
 */
@Composable
fun InstalledAppsScreen(
    uiState: P2PUiState,
    onBack: () -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onToggleSystemApps: (Boolean) -> Unit,
    onRefreshApps: () -> Unit,
    onToggleSelectApp: (String) -> Unit,
    onSelectAllVisible: (List<String>) -> Unit,
    onClearSelection: () -> Unit,
    onAddSelectedToSend: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    val filteredApps = remember(uiState.installedApps, uiState.appsSearchQuery) {
        val q = uiState.appsSearchQuery.trim().lowercase(Locale.ROOT)
        if (q.isEmpty()) uiState.installedApps
        else uiState.installedApps.filter {
            it.appName.lowercase(Locale.ROOT).contains(q) ||
                it.packageName.lowercase(Locale.ROOT).contains(q)
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    ScreenTopBar(
                        title = "التطبيقات المثبتة (${filteredApps.size})",
                        subtitle = "حدد تطبيقاً أو أكثر لإرسال حزمة التثبيت APK",
                        accentColor = NeonEmerald,
                        onBack = onBack
                    )
                }
                IconButton(
                    onClick = onRefreshApps,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(MidnightCard)
                        .border(1.dp, GlassBorder, CircleShape)
                        .testTag("refresh_installed_apps_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Refresh,
                        contentDescription = "تحديث قائمة التطبيقات",
                        tint = ElectricCyan
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Important Android APK sharing notice (Section 3 requirement)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF1A2234))
                    .border(1.dp, HotspotAmber.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                    .padding(10.dp)
            ) {
                Text(
                    text = "تنبيه تقني: إرسال التطبيق يشارك ملف التثبيت الأساسي (APK) فقط ولا يشمل بيانات التطبيق الخاصة أو الحسابات المسجلة. التطبيقات المقسمة (Split APKs) قد تتطلب مثبت حزم مخصص على الجهاز المستلم.",
                    style = MaterialTheme.typography.labelMedium,
                    color = Color(0xFFFDE68A)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Search & System Apps Filter Row
            OutlinedTextField(
                value = uiState.appsSearchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = { Text("ابحث باسم التطبيق أو اسم الحزمة (Package)...", fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = ElectricCyan) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricCyan,
                    unfocusedBorderColor = GlassBorder,
                    focusedContainerColor = MidnightSurface,
                    unfocusedContainerColor = MidnightSurface
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("apps_search_input")
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(
                        checked = uiState.includeSystemApps,
                        onCheckedChange = onToggleSystemApps,
                        colors = SwitchDefaults.colors(checkedThumbColor = ElectricCyan),
                        modifier = Modifier.testTag("toggle_system_apps_switch")
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "إظهار تطبيقات النظام",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextSecondary
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = { onSelectAllVisible(filteredApps.map { it.packageName }) },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("select_all_apps_button")
                    ) {
                        Icon(Icons.Filled.SelectAll, contentDescription = null, tint = ElectricCyan, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("تحديد الكل", fontSize = 12.sp, color = Color.White)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (uiState.isLoadingApps) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = ElectricCyan)
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("جاري فحص التطبيقات المثبتة وجلب الأيقونات الحقيقية...", color = TextSecondary)
                    }
                }
            } else if (filteredApps.isEmpty()) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(MidnightCard)
                        .padding(24.dp)
                ) {
                    Text(
                        text = "لا توجد تطبيقات مطابقة للبحث. يمكنك تفعيل خيار (إظهار تطبيقات النظام) لعرض كافة الحزم المثبتة.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .testTag("installed_apps_lazy_column")
                ) {
                    items(filteredApps, key = { it.packageName }) { app ->
                        val isSelected = app.packageName in uiState.selectedAppPackages
                        InstalledAppRowCard(
                            app = app,
                            isSelected = isSelected,
                            onToggleSelect = { onToggleSelectApp(app.packageName) }
                        )
                    }
                }
            }
        }

        SelectionBottomActionBar(
            selectedCount = uiState.totalSelectedCountInManager,
            selectedBytes = uiState.totalSelectedBytesInManager,
            onClearSelection = onClearSelection,
            onAddSelectedToSendQueue = onAddSelectedToSend
        )

        CopyrightFooter()
    }
}

@Composable
private fun InstalledAppRowCard(
    app: InstalledAppItem,
    isSelected: Boolean,
    onToggleSelect: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(if (isSelected) Color(0xFF102A3A) else MidnightCard)
            .border(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = if (isSelected) ElectricCyan else GlassBorder,
                shape = RoundedCornerShape(16.dp)
            )
            .clickable(onClick = onToggleSelect)
            .padding(12.dp)
            .testTag("installed_app_card_${app.packageName}")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            // Real colored application icon from PackageManager
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(50.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0A1424))
                    .padding(4.dp)
            ) {
                if (app.iconBitmap != null) {
                    Image(
                        bitmap = app.iconBitmap,
                        contentDescription = app.appName,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = Icons.Filled.Android,
                        contentDescription = app.appName,
                        tint = NeonEmerald,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = app.appName,
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (app.hasSplitApks) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            color = HotspotAmber.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "Split (${app.splitCount + 1})",
                                fontSize = 10.sp,
                                color = HotspotAmber,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
                Text(
                    text = app.packageName,
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 11.sp,
                    color = TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "الإصدار: v${app.versionName} • الحجم: ${formatBytesArabic(app.sizeBytes)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = ElectricCyan
                )
            }
        }

        Checkbox(
            checked = isSelected,
            onCheckedChange = { onToggleSelect() },
            colors = CheckboxDefaults.colors(
                checkedColor = ElectricCyan,
                checkmarkColor = Color(0xFF002229)
            )
        )
    }
}

/**
 * Section 2: Real Media Category Screen (Used for Images, Videos, and Audio/Music tabs).
 * Displays real thumbnails, durations, sizes, search, sorting, runtime permission prompt, and SAF picker.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MediaCategoryScreen(
    title: String,
    subtitle: String,
    category: FileCategory,
    items: List<DeviceMediaItem>,
    uiState: P2PUiState,
    onBack: () -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onSortOptionChange: (SortOption) -> Unit,
    onPermissionsResult: (Map<String, Boolean>) -> Unit,
    onRefreshMedia: () -> Unit,
    onPickSafFiles: (List<Uri>) -> Unit,
    onToggleSelectMedia: (String) -> Unit,
    onSelectAllVisible: (List<String>) -> Unit,
    onClearSelection: () -> Unit,
    onAddSelectedToSend: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    val permissionsToRequest = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO
            )
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { resultMap ->
        onPermissionsResult(resultMap)
    }

    val safFilePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) onPickSafFiles(uris)
    }

    val filteredAndSorted = remember(items, uiState.mediaSearchQuery, uiState.sortOption) {
        val q = uiState.mediaSearchQuery.trim().lowercase(Locale.ROOT)
        val filtered = if (q.isEmpty()) items else items.filter {
            it.name.lowercase(Locale.ROOT).contains(q) ||
                it.bucketOrFolderName.lowercase(Locale.ROOT).contains(q)
        }
        when (uiState.sortOption) {
            SortOption.DATE_DESC -> filtered.sortedByDescending { it.dateModifiedMillis }
            SortOption.NAME_ASC -> filtered.sortedBy { it.name.lowercase(Locale.ROOT) }
            SortOption.SIZE_DESC -> filtered.sortedByDescending { it.sizeBytes }
            SortOption.SIZE_ASC -> filtered.sortedBy { it.sizeBytes }
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    ScreenTopBar(
                        title = "$title (${filteredAndSorted.size})",
                        subtitle = subtitle,
                        accentColor = Color(category.badgeColorHex),
                        onBack = onBack
                    )
                }
                IconButton(
                    onClick = onRefreshMedia,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(MidnightCard)
                        .border(1.dp, GlassBorder, CircleShape)
                ) {
                    Icon(Icons.Filled.Refresh, contentDescription = "تحديث", tint = ElectricCyan)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Runtime Permission Banner if not granted
            if (!uiState.hasMediaPermissions) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF28190B))
                        .border(1.dp, HotspotAmber, RoundedCornerShape(16.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Text(
                            text = uiState.permissionDeniedMessage
                                ?: "لعرض جميع الصور والفيديوهات والصوتيات الموجودة على جهازك تلقائياً عبر MediaStore، يرجى منح صلاحية قراءة الوسائط.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { permissionLauncher.launch(permissionsToRequest) },
                                colors = ButtonDefaults.buttonColors(containerColor = HotspotAmber),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.testTag("grant_media_permissions_button")
                            ) {
                                Icon(Icons.Filled.LockOpen, contentDescription = null, tint = Color(0xFF1F1200), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("منح صلاحية الوسائط", color = Color(0xFF1F1200), fontWeight = FontWeight.Bold)
                            }
                            OutlinedButton(
                                onClick = {
                                    val mimeFilter = when (category) {
                                        FileCategory.IMAGE -> arrayOf("image/*")
                                        FileCategory.VIDEO -> arrayOf("video/*")
                                        FileCategory.AUDIO -> arrayOf("audio/*")
                                        else -> arrayOf("*/*")
                                    }
                                    safFilePickerLauncher.launch(mimeFilter)
                                },
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("اختيار عبر النظام (SAF)", color = ElectricCyan)
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            // Search & Sort Controls
            OutlinedTextField(
                value = uiState.mediaSearchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = { Text("ابحث بالاسم أو المجلد...", fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = ElectricCyan) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricCyan,
                    unfocusedBorderColor = GlassBorder,
                    focusedContainerColor = MidnightSurface,
                    unfocusedContainerColor = MidnightSurface
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("media_search_input")
            )

            Spacer(modifier = Modifier.height(8.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                SortOption.entries.forEach { sort ->
                    FilterChip(
                        selected = uiState.sortOption == sort,
                        onClick = { onSortOptionChange(sort) },
                        label = { Text(sort.arabicLabel, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ElectricCyan.copy(alpha = 0.22f),
                            selectedLabelColor = ElectricCyan
                        )
                    )
                }
                FilterChip(
                    selected = false,
                    onClick = { onSelectAllVisible(filteredAndSorted.map { it.id }) },
                    label = { Text("تحديد الكل", fontSize = 11.sp, color = NeonEmerald) }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (uiState.isLoadingMedia) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    CircularProgressIndicator(color = ElectricCyan)
                }
            } else if (filteredAndSorted.isEmpty()) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(MidnightCard)
                        .padding(24.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "لا توجد ملفات معروضة في هذا القسم حالياً.",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = { safFilePickerLauncher.launch(arrayOf("*/*")) }
                        ) {
                            Icon(Icons.Filled.FolderOpen, contentDescription = null, tint = ElectricCyan)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("اختيار ملفات مباشرة من الهاتف (SAF)", color = ElectricCyan)
                        }
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .testTag("media_items_lazy_column")
                ) {
                    items(filteredAndSorted, key = { it.id }) { item ->
                        MediaItemRowCard(
                            item = item,
                            isSelected = item.id in uiState.selectedMediaIds,
                            onToggleSelect = { onToggleSelectMedia(item.id) }
                        )
                    }
                }
            }
        }

        SelectionBottomActionBar(
            selectedCount = uiState.totalSelectedCountInManager,
            selectedBytes = uiState.totalSelectedBytesInManager,
            onClearSelection = onClearSelection,
            onAddSelectedToSendQueue = onAddSelectedToSend
        )

        CopyrightFooter()
    }
}

/**
 * Section 2: General Files & Folders Manager Screen (Downloads, Recent, Documents/PDF, ZIP/RAR, APKs, Folders & SAF).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FilesAndFoldersScreen(
    uiState: P2PUiState,
    onBack: () -> Unit,
    onSubTabChange: (FilesSubTab) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onSortOptionChange: (SortOption) -> Unit,
    onPickSafFiles: (List<Uri>) -> Unit,
    onPickSafFolder: (Uri) -> Unit,
    onSendLocalFolderDirectly: (String) -> Unit = {},
    onRefreshFiles: () -> Unit,
    onToggleSelectMedia: (String) -> Unit,
    onSelectAllVisible: (List<String>) -> Unit,
    onClearSelection: () -> Unit,
    onAddSelectedToSend: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    val safFilesLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) onPickSafFiles(uris)
    }

    val safTreeLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri ->
        if (treeUri != null) onPickSafFolder(treeUri)
    }

    val displayedFiles = remember(
        uiState.deviceGeneralFiles,
        uiState.safFolderFiles,
        uiState.activeFilesSubTab,
        uiState.mediaSearchQuery,
        uiState.sortOption
    ) {
        val baseList = when (uiState.activeFilesSubTab) {
            FilesSubTab.DOWNLOADS -> uiState.deviceGeneralFiles.filter {
                it.id.startsWith("dl_") || it.bucketOrFolderName.equals("Download", ignoreCase = true) ||
                    it.bucketOrFolderName.equals("BarqSher", ignoreCase = true)
            }
            FilesSubTab.RECENT -> uiState.deviceGeneralFiles.take(80)
            FilesSubTab.DOCUMENTS -> uiState.deviceGeneralFiles.filter { it.category == FileCategory.DOCUMENT }
            FilesSubTab.ARCHIVES -> uiState.deviceGeneralFiles.filter { it.category == FileCategory.ARCHIVE }
            FilesSubTab.APKS -> uiState.deviceGeneralFiles.filter { it.category == FileCategory.GAME_APK }
            FilesSubTab.FOLDERS -> uiState.safFolderFiles.ifEmpty { uiState.deviceGeneralFiles }
        }
        val q = uiState.mediaSearchQuery.trim().lowercase(Locale.ROOT)
        val filtered = if (q.isEmpty()) baseList else baseList.filter {
            it.name.lowercase(Locale.ROOT).contains(q) ||
                it.bucketOrFolderName.lowercase(Locale.ROOT).contains(q)
        }
        when (uiState.sortOption) {
            SortOption.DATE_DESC -> filtered.sortedByDescending { it.dateModifiedMillis }
            SortOption.NAME_ASC -> filtered.sortedBy { it.name.lowercase(Locale.ROOT) }
            SortOption.SIZE_DESC -> filtered.sortedByDescending { it.sizeBytes }
            SortOption.SIZE_ASC -> filtered.sortedBy { it.sizeBytes }
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    ScreenTopBar(
                        title = "مدير الملفات والمجلدات",
                        subtitle = "التنزيلات، المستندات، المضغوطة، APK وإرسال المجلدات الكاملة",
                        accentColor = HotspotAmber,
                        onBack = onBack
                    )
                }
                IconButton(
                    onClick = onRefreshFiles,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(MidnightCard)
                        .border(1.dp, GlassBorder, CircleShape)
                ) {
                    Icon(Icons.Filled.Refresh, contentDescription = "تحديث", tint = ElectricCyan)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Sub-tabs for Downloads, Recent, Documents, Archives, APKs, Folders
            ScrollableTabRow(
                selectedTabIndex = FilesSubTab.entries.indexOf(uiState.activeFilesSubTab),
                containerColor = MidnightSurface,
                contentColor = ElectricCyan,
                edgePadding = 0.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
            ) {
                FilesSubTab.entries.forEach { tab ->
                    val selected = tab == uiState.activeFilesSubTab
                    Tab(
                        selected = selected,
                        onClick = { onSubTabChange(tab) },
                        text = {
                            Text(
                                text = tab.arabicLabel,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                color = if (selected) ElectricCyan else TextSecondary
                            )
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // SAF Action Buttons for picking any file or sending an entire folder (ACTION_OPEN_DOCUMENT_TREE)
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = { safFilesLauncher.launch(arrayOf("*/*")) },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("saf_pick_files_button")
                ) {
                    Icon(Icons.Filled.FolderOpen, contentDescription = null, tint = Color(0xFF002229), modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("اختيار ملفات (SAF)", color = Color(0xFF002229), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                Button(
                    onClick = { safTreeLauncher.launch(null) },
                    colors = ButtonDefaults.buttonColors(containerColor = HotspotAmber),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("saf_pick_folder_tree_button")
                ) {
                    Icon(Icons.Filled.CreateNewFolder, contentDescription = null, tint = Color(0xFF1F1200), modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("إرسال مجلد كامل", color = Color(0xFF1F1200), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = uiState.mediaSearchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = { Text("ابحث في ${uiState.activeFilesSubTab.arabicLabel}...", fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = ElectricCyan) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricCyan,
                    unfocusedBorderColor = GlassBorder,
                    focusedContainerColor = MidnightSurface,
                    unfocusedContainerColor = MidnightSurface
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(6.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                SortOption.entries.forEach { sort ->
                    FilterChip(
                        selected = uiState.sortOption == sort,
                        onClick = { onSortOptionChange(sort) },
                        label = { Text(sort.arabicLabel, fontSize = 11.sp) }
                    )
                }
                if (displayedFiles.isNotEmpty()) {
                    FilterChip(
                        selected = false,
                        onClick = { onSelectAllVisible(displayedFiles.map { it.id }) },
                        label = { Text("تحديد الكل (${displayedFiles.size})", fontSize = 11.sp, color = NeonEmerald) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .testTag("files_manager_lazy_column")
            ) {
                if (uiState.activeFilesSubTab == FilesSubTab.FOLDERS && uiState.storageFolders.isNotEmpty()) {
                    items(uiState.storageFolders, key = { it.path }) { folder ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(MidnightSurface)
                                .border(1.dp, HotspotAmber.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                                .padding(12.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Filled.Folder, contentDescription = null, tint = HotspotAmber, modifier = Modifier.size(28.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(folder.name, style = MaterialTheme.typography.titleMedium, color = Color.White)
                                    Text(
                                        text = "${folder.fileCount} ملف • ${formatBytesArabic(folder.totalBytes)} • ${folder.path}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = TextSecondary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = { onSendLocalFolderDirectly(folder.path) },
                                colors = ButtonDefaults.buttonColors(containerColor = HotspotAmber),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.testTag("send_local_folder_${folder.name}")
                            ) {
                                Text(
                                    text = "إرسال المجلد",
                                    color = Color(0xFF1F1200),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }

                if (displayedFiles.isEmpty()) {
                    item {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(MidnightCard)
                                .padding(24.dp)
                        ) {
                            Text(
                                text = "لا توجد ملفات في قسم (${uiState.activeFilesSubTab.arabicLabel}) حالياً. اضغط (اختيار ملفات SAF) أو (فتح مجلد كامل) أعلاه للوصول إلى أي ملف على جهازك.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                } else {
                    items(displayedFiles, key = { it.id }) { item ->
                        MediaItemRowCard(
                            item = item,
                            isSelected = item.id in uiState.selectedMediaIds,
                            onToggleSelect = { onToggleSelectMedia(item.id) }
                        )
                    }
                }
            }
        }

        SelectionBottomActionBar(
            selectedCount = uiState.totalSelectedCountInManager,
            selectedBytes = uiState.totalSelectedBytesInManager,
            onClearSelection = onClearSelection,
            onAddSelectedToSendQueue = onAddSelectedToSend
        )

        CopyrightFooter()
    }
}

@Composable
private fun MediaItemRowCard(
    item: DeviceMediaItem,
    isSelected: Boolean,
    onToggleSelect: () -> Unit
) {
    val badgeColor = Color(item.category.badgeColorHex)
    val durationText = formatDurationArabic(item.durationMillis)
    val dateText = remember(item.dateModifiedMillis) {
        if (item.dateModifiedMillis <= 0L) ""
        else SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(item.dateModifiedMillis))
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (isSelected) Color(0xFF102A3A) else MidnightCard)
            .border(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = if (isSelected) ElectricCyan else GlassBorder,
                shape = RoundedCornerShape(14.dp)
            )
            .clickable(onClick = onToggleSelect)
            .padding(10.dp)
            .testTag("media_item_card_${item.id}")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(badgeColor.copy(alpha = 0.18f))
            ) {
                if (item.thumbnailBitmap != null) {
                    Image(
                        bitmap = item.thumbnailBitmap,
                        contentDescription = item.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = categoryIcon(item.category),
                        contentDescription = item.category.arabicLabel,
                        tint = badgeColor,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.name,
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                val metaParts = buildList {
                    add(formatBytesArabic(item.sizeBytes))
                    if (durationText.isNotEmpty()) add("المدة: $durationText")
                    if (item.bucketOrFolderName.isNotEmpty()) add(item.bucketOrFolderName)
                    if (dateText.isNotEmpty()) add(dateText)
                }
                Text(
                    text = metaParts.joinToString(" • "),
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Icon(
            imageVector = if (isSelected) Icons.Filled.CheckBox else Icons.Filled.CheckBoxOutlineBlank,
            contentDescription = if (isSelected) "محدد" else "غير محدد",
            tint = if (isSelected) ElectricCyan else TextSecondary,
            modifier = Modifier.padding(start = 8.dp)
        )
    }
}

/**
 * Section 6: Transfer History Screen showing all sent and received files,
 * SHA-256 verification status, saved paths, and transfer speeds.
 */
@Composable
fun TransferHistoryScreen(
    uiState: P2PUiState,
    onBack: () -> Unit,
    onClearHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    Column(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    ScreenTopBar(
                        title = "سجل النقل (${uiState.transferHistory.size})",
                        subtitle = "سجل العمليات المكتملة والتحقق من سلامة الملفات SHA-256",
                        accentColor = ElectricCyan,
                        onBack = onBack
                    )
                }
                if (uiState.transferHistory.isNotEmpty()) {
                    IconButton(
                        onClick = onClearHistory,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(MidnightCard)
                            .border(1.dp, GlassBorder, CircleShape)
                            .testTag("clear_history_button")
                    ) {
                        Icon(Icons.Filled.DeleteSweep, contentDescription = "مسح السجل", tint = CoralRose)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (uiState.transferHistory.isEmpty()) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(18.dp))
                        .background(MidnightCard)
                        .border(1.dp, GlassBorder, RoundedCornerShape(18.dp))
                        .padding(24.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Filled.History,
                            contentDescription = null,
                            tint = TextSecondary,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "سجل النقل فارغ حالياً. ستظهر هنا جميع الملفات والتطبيقات التي يتم إرسالها أو استلامها مع حالة التحقق SHA-256.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .testTag("transfer_history_lazy_column")
                ) {
                    items(uiState.transferHistory, key = { it.id }) { record ->
                        HistoryRecordCard(record = record)
                    }
                }
            }
        }

        CopyrightFooter()
    }
}

@Composable
private fun HistoryRecordCard(record: TransferHistoryRecord) {
    val isSuccess = record.status == FileTransferStatus.COMPLETED
    val statusColor = if (isSuccess) NeonEmerald else CoralRose
    val timeStr = remember(record.timestampMillis) {
        SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date(record.timestampMillis))
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MidnightCard)
            .border(1.dp, statusColor.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = if (isSuccess) Icons.Filled.CheckCircle else Icons.Filled.ErrorOutline,
                        contentDescription = null,
                        tint = statusColor,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = record.fileName,
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Surface(
                    color = statusColor.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(999.dp)
                ) {
                    Text(
                        text = if (record.direction == TransferDirection.SENDING) "إرسال" else "استلام",
                        style = MaterialTheme.typography.labelMedium,
                        color = statusColor,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "الحجم: ${formatBytesArabic(record.sizeBytes)} • متوسط السرعة: ${formatSpeedArabic(record.averageSpeedBytesPerSec)} • $timeStr",
                style = MaterialTheme.typography.labelMedium,
                color = TextSecondary
            )

            if (record.sha256Verified || record.sha256Hash.isNotEmpty()) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.VerifiedUser,
                        contentDescription = null,
                        tint = NeonEmerald,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "SHA-256 سليم ومطابق: ${record.sha256Hash.take(16)}...",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 11.sp,
                        color = NeonEmerald
                    )
                }
            }

            record.savedPath?.let { path ->
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "المسار: $path",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 10.sp,
                    color = ElectricCyan,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            record.errorMessage?.let { err ->
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "السبب: $err",
                    style = MaterialTheme.typography.labelMedium,
                    color = CoralRose
                )
            }
        }
    }
}
