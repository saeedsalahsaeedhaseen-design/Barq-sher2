package com.example.data

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.media.ThumbnailUtils
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.util.Size
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.example.model.DeviceMediaItem
import com.example.model.FileCategory
import com.example.model.FolderBatchInfo
import com.example.model.StorageFolderItem
import com.example.model.TransferFileItem
import com.example.util.Sha256Util
import java.io.File
import java.net.URLDecoder
import java.util.Locale
import java.util.UUID
import kotlin.math.max

/**
 * Queries real device media and files via MediaStore, accessible storage directories,
 * and Storage Access Framework (SAF) DocumentTrees.
 */
object DeviceMediaRepository {

    fun loadImages(context: Context, maxItems: Int = 250): List<DeviceMediaItem> {
        val resolver = context.contentResolver
        val items = mutableListOf<DeviceMediaItem>()
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.SIZE,
            MediaStore.Images.Media.DATE_MODIFIED,
            MediaStore.Images.Media.MIME_TYPE,
            MediaStore.Images.Media.BUCKET_DISPLAY_NAME
        )
        val sortOrder = "${MediaStore.Images.Media.DATE_MODIFIED} DESC"
        try {
            resolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE)
                val bucketCol = cursor.getColumnIndex(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)

                var count = 0
                while (cursor.moveToNext() && count < maxItems) {
                    val id = cursor.getLong(idCol)
                    val name = cursor.getString(nameCol) ?: "IMG_$id.jpg"
                    val size = cursor.getLong(sizeCol)
                    if (size <= 0L) continue
                    val dateSec = cursor.getLong(dateCol)
                    val mime = cursor.getString(mimeCol)
                    val bucket = if (bucketCol >= 0) cursor.getString(bucketCol) ?: "" else ""
                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        id
                    )
                    val thumb = if (count < 60) loadMediaThumbnail(resolver, contentUri, id, isVideo = false) else null
                    items.add(
                        DeviceMediaItem(
                            id = "img_$id",
                            name = name,
                            uri = contentUri,
                            sizeBytes = size,
                            dateModifiedMillis = dateSec * 1000L,
                            mimeType = mime,
                            bucketOrFolderName = bucket,
                            category = FileCategory.IMAGE,
                            thumbnailBitmap = thumb
                        )
                    )
                    count++
                }
            }
        } catch (_: Exception) {
        }
        return items
    }

    fun loadVideos(context: Context, maxItems: Int = 200): List<DeviceMediaItem> {
        val resolver = context.contentResolver
        val items = mutableListOf<DeviceMediaItem>()
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_MODIFIED,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.MIME_TYPE,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME
        )
        val sortOrder = "${MediaStore.Video.Media.DATE_MODIFIED} DESC"
        try {
            resolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_MODIFIED)
                val durCol = cursor.getColumnIndex(MediaStore.Video.Media.DURATION)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)
                val bucketCol = cursor.getColumnIndex(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)

                var count = 0
                while (cursor.moveToNext() && count < maxItems) {
                    val id = cursor.getLong(idCol)
                    val name = cursor.getString(nameCol) ?: "VID_$id.mp4"
                    val size = cursor.getLong(sizeCol)
                    if (size <= 0L) continue
                    val dateSec = cursor.getLong(dateCol)
                    val duration = if (durCol >= 0) cursor.getLong(durCol) else 0L
                    val mime = cursor.getString(mimeCol)
                    val bucket = if (bucketCol >= 0) cursor.getString(bucketCol) ?: "" else ""
                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                        id
                    )
                    val thumb = if (count < 40) loadMediaThumbnail(resolver, contentUri, id, isVideo = true) else null
                    items.add(
                        DeviceMediaItem(
                            id = "vid_$id",
                            name = name,
                            uri = contentUri,
                            sizeBytes = size,
                            dateModifiedMillis = dateSec * 1000L,
                            durationMillis = duration,
                            mimeType = mime,
                            bucketOrFolderName = bucket,
                            category = FileCategory.VIDEO,
                            thumbnailBitmap = thumb
                        )
                    )
                    count++
                }
            }
        } catch (_: Exception) {
        }
        return items
    }

    fun loadAudioFiles(context: Context, maxItems: Int = 250): List<DeviceMediaItem> {
        val resolver = context.contentResolver
        val items = mutableListOf<DeviceMediaItem>()
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_MODIFIED,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.ARTIST
        )
        val sortOrder = "${MediaStore.Audio.Media.DATE_MODIFIED} DESC"
        try {
            resolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val nameCol = cursor.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME)
                val titleCol = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_MODIFIED)
                val durCol = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION)
                val mimeCol = cursor.getColumnIndex(MediaStore.Audio.Media.MIME_TYPE)
                val artistCol = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST)

                var count = 0
                while (cursor.moveToNext() && count < maxItems) {
                    val id = cursor.getLong(idCol)
                    val displayName = (if (nameCol >= 0) cursor.getString(nameCol) else null)
                        ?: (if (titleCol >= 0) cursor.getString(titleCol) else null)
                        ?: "Audio_$id.mp3"
                    val size = cursor.getLong(sizeCol)
                    if (size <= 0L) continue
                    val dateSec = cursor.getLong(dateCol)
                    val duration = if (durCol >= 0) cursor.getLong(durCol) else 0L
                    val mime = if (mimeCol >= 0) cursor.getString(mimeCol) else "audio/mpeg"
                    val artist = if (artistCol >= 0) cursor.getString(artistCol) ?: "" else ""
                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        id
                    )
                    items.add(
                        DeviceMediaItem(
                            id = "aud_$id",
                            name = displayName,
                            uri = contentUri,
                            sizeBytes = size,
                            dateModifiedMillis = dateSec * 1000L,
                            durationMillis = duration,
                            mimeType = mime,
                            bucketOrFolderName = artist,
                            category = FileCategory.AUDIO
                        )
                    )
                    count++
                }
            }
        } catch (_: Exception) {
        }
        return items
    }

    /**
     * Loads general files (Documents, PDFs, ZIP/RAR Archives, APKs, Downloads, Recent files)
     * from MediaStore.Files, MediaStore.Downloads (API 29+), and accessible storage directories.
     */
    fun loadGeneralFilesAndFolders(
        context: Context
    ): Pair<List<DeviceMediaItem>, List<StorageFolderItem>> {
        val resolver = context.contentResolver
        val seenKeys = HashSet<String>()
        val allFiles = mutableListOf<DeviceMediaItem>()

        // 1. Query MediaStore.Downloads on API 29+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val dlProjection = arrayOf(
                MediaStore.Downloads._ID,
                MediaStore.Downloads.DISPLAY_NAME,
                MediaStore.Downloads.SIZE,
                MediaStore.Downloads.DATE_MODIFIED,
                MediaStore.Downloads.MIME_TYPE
            )
            try {
                resolver.query(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    dlProjection,
                    null,
                    null,
                    "${MediaStore.Downloads.DATE_MODIFIED} DESC"
                )?.use { cursor ->
                    val idCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads._ID)
                    val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.DISPLAY_NAME)
                    val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.SIZE)
                    val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.DATE_MODIFIED)
                    val mimeCol = cursor.getColumnIndex(MediaStore.Downloads.MIME_TYPE)

                    while (cursor.moveToNext()) {
                        val id = cursor.getLong(idCol)
                        val name = cursor.getString(nameCol) ?: continue
                        val size = cursor.getLong(sizeCol)
                        if (size <= 0L) continue
                        val dateSec = cursor.getLong(dateCol)
                        val mime = if (mimeCol >= 0) cursor.getString(mimeCol) else null
                        val uri = ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, id)
                        val key = "$name:$size"
                        if (seenKeys.add(key)) {
                            allFiles.add(
                                DeviceMediaItem(
                                    id = "dl_$id",
                                    name = name,
                                    uri = uri,
                                    sizeBytes = size,
                                    dateModifiedMillis = dateSec * 1000L,
                                    mimeType = mime,
                                    bucketOrFolderName = "Download",
                                    category = FileCategory.fromFileName(name, mime)
                                )
                            )
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }

        // 2. Query MediaStore.Files for Documents, Archives, APKs, and Recent files
        val filesUri = MediaStore.Files.getContentUri("external")
        val fileProj = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.SIZE,
            MediaStore.Files.FileColumns.DATE_MODIFIED,
            MediaStore.Files.FileColumns.MIME_TYPE,
            MediaStore.Images.Media.BUCKET_DISPLAY_NAME
        )
        try {
            resolver.query(
                filesUri,
                fileProj,
                "${MediaStore.Files.FileColumns.SIZE} > 0",
                null,
                "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
                val nameCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_MODIFIED)
                val mimeCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.MIME_TYPE)
                val bucketCol = cursor.getColumnIndex(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)

                var count = 0
                while (cursor.moveToNext() && count < 300) {
                    val id = cursor.getLong(idCol)
                    val name = (if (nameCol >= 0) cursor.getString(nameCol) else null) ?: continue
                    val size = cursor.getLong(sizeCol)
                    if (size <= 0L) continue
                    val dateSec = cursor.getLong(dateCol)
                    val mime = if (mimeCol >= 0) cursor.getString(mimeCol) else null
                    val bucket = if (bucketCol >= 0) cursor.getString(bucketCol) ?: "التخزين" else "التخزين"
                    val key = "$name:$size"
                    if (seenKeys.add(key)) {
                        val contentUri = ContentUris.withAppendedId(filesUri, id)
                        allFiles.add(
                            DeviceMediaItem(
                                id = "file_$id",
                                name = name,
                                uri = contentUri,
                                sizeBytes = size,
                                dateModifiedMillis = dateSec * 1000L,
                                mimeType = mime,
                                bucketOrFolderName = bucket,
                                category = FileCategory.fromFileName(name, mime)
                            )
                        )
                        count++
                    }
                }
            }
        } catch (_: Exception) {
        }

        // 3. Scan directly accessible directories (e.g. Downloads, BarqSher, Documents, app external dirs)
        val candidateDirs = mutableListOf<File>()
        try {
            @Suppress("DEPRECATION")
            val pubDownload = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (pubDownload != null) {
                candidateDirs.add(pubDownload)
                candidateDirs.add(File(pubDownload, "BarqSher"))
            }
            @Suppress("DEPRECATION")
            val pubDocs = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
            if (pubDocs != null) candidateDirs.add(pubDocs)
        } catch (_: Exception) {
        }
        context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)?.let {
            candidateDirs.add(it)
            candidateDirs.add(File(it, "BarqSher"))
        }

        val folderSummaries = mutableListOf<StorageFolderItem>()
        for (dir in candidateDirs.distinctBy { it.absolutePath }) {
            if (!dir.exists() || !dir.isDirectory || !dir.canRead()) continue
            val children = dir.listFiles() ?: continue
            var dirTotalBytes = 0L
            var dirFileCount = 0
            var dirSubfolderCount = 0
            for (child in children) {
                if (child.isDirectory && child.canRead()) {
                    dirSubfolderCount++
                    val subScan = countFilesAndBytesRecursively(child)
                    dirFileCount += subScan.first
                    dirTotalBytes += subScan.second
                } else if (child.isFile && child.canRead()) {
                    dirFileCount++
                    dirTotalBytes += child.length()
                    if (child.length() > 0) {
                        val key = "${child.name}:${child.length()}"
                        if (seenKeys.add(key)) {
                            allFiles.add(
                                DeviceMediaItem(
                                    id = "disk_${child.absolutePath.hashCode()}",
                                    name = child.name,
                                    localFile = child,
                                    sizeBytes = child.length(),
                                    dateModifiedMillis = child.lastModified(),
                                    bucketOrFolderName = dir.name,
                                    category = FileCategory.fromFileName(child.name)
                                )
                            )
                        }
                    }
                }
            }
            folderSummaries.add(
                StorageFolderItem(
                    name = dir.name,
                    path = dir.absolutePath,
                    fileCount = dirFileCount,
                    subfolderCount = dirSubfolderCount,
                    totalBytes = dirTotalBytes,
                    lastModifiedMillis = dir.lastModified()
                )
            )
        }

        return allFiles to folderSummaries
    }

    private fun countFilesAndBytesRecursively(dir: File, maxDepth: Int = 6): Pair<Int, Long> {
        if (maxDepth <= 0 || !dir.exists() || !dir.isDirectory || !dir.canRead()) return 0 to 0L
        val list = dir.listFiles() ?: return 0 to 0L
        var filesCount = 0
        var bytesCount = 0L
        for (f in list) {
            if (f.isDirectory && f.canRead()) {
                val sub = countFilesAndBytesRecursively(f, maxDepth - 1)
                filesCount += sub.first
                bytesCount += sub.second
            } else if (f.isFile && f.canRead()) {
                filesCount++
                bytesCount += f.length()
            }
        }
        return filesCount to bytesCount
    }

    data class FolderScanResult(
        val batchInfo: FolderBatchInfo?,
        val transferItems: List<TransferFileItem>,
        val previewMediaItems: List<DeviceMediaItem>,
        val errorMessage: String? = null
    )

    /**
     * Recursively reads an entire user-selected folder from ACTION_OPEN_DOCUMENT_TREE,
     * persisting read permissions and building a unified transfer manifest that preserves
     * all nested subdirectories, relative paths, empty folders, and 0-byte files.
     */
    fun scanDocumentTreeForTransfer(
        context: Context,
        treeUri: Uri,
        chunkSizeBytes: Int
    ): FolderScanResult {
        val resolver = context.contentResolver
        var hasPersistentPerm = false
        try {
            resolver.takePersistableUriPermission(
                treeUri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            hasPersistentPerm = true
        } catch (_: SecurityException) {
            // Provider may only grant transient session read permission
        } catch (_: Exception) {
        }

        val rootDocId = try {
            DocumentsContract.getTreeDocumentId(treeUri)
        } catch (e: Exception) {
            return FolderScanResult(
                batchInfo = null,
                transferItems = emptyList(),
                previewMediaItems = emptyList(),
                errorMessage = "تعذر قراءة معرّف المجلد المختار: ${e.localizedMessage ?: "URI غير صالح"}"
            )
        }

        val lowerDocId = rootDocId.lowercase(Locale.ROOT)
        if (lowerDocId.contains("android/data") || lowerDocId.contains("android/obb")) {
            return FolderScanResult(
                batchInfo = null,
                transferItems = emptyList(),
                previewMediaItems = emptyList(),
                errorMessage = "هذا المجلد (${rootDocId}) محمي من نظام Android 11+ (Android/data أو Android/obb) ولا يسمح النظام بالوصول إليه بدون صلاحيات خاصة."
            )
        }

        val rootFolderName = sanitizePathSegment(resolveTreeRootFolderName(resolver, treeUri, rootDocId))
        val batchId = "fld_${UUID.randomUUID().toString().take(8)}"
        val transferItems = mutableListOf<TransferFileItem>()
        val previewItems = mutableListOf<DeviceMediaItem>()
        var totalFilesCount = 0
        var totalSubfoldersCount = 0
        var emptyFoldersCount = 0
        var totalBytes = 0L
        var skippedUnreadableCount = 0

        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )

        fun traverseDir(currentDocId: String, currentRelPath: String, depth: Int): Int {
            if (depth > 24) return 0
            val childrenUri = try {
                DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, currentDocId)
            } catch (_: Exception) {
                skippedUnreadableCount++
                return 0
            }

            var entriesInThisDir = 0
            val usedSiblingNames = HashSet<String>()

            try {
                val cursor = resolver.query(childrenUri, projection, null, null, null)
                if (cursor == null) {
                    skippedUnreadableCount++
                    return 0
                }
                cursor.use { c ->
                    val idCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                    val nameCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                    val sizeCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_SIZE)
                    val dateCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED)
                    val mimeCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)

                    while (c.moveToNext()) {
                        val childDocId = c.getString(idCol) ?: continue
                        val rawName = c.getString(nameCol) ?: "عنصر_${entriesInThisDir + 1}"
                        val safeName = deduplicateSiblingName(sanitizePathSegment(rawName), usedSiblingNames)
                        val mime = if (mimeCol >= 0) c.getString(mimeCol) else null
                        val lastMod = if (dateCol >= 0 && !c.isNull(dateCol)) c.getLong(dateCol) else System.currentTimeMillis()
                        val childRelPath = "$currentRelPath/$safeName"
                        entriesInThisDir++

                        if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                            totalSubfoldersCount++
                            val subEntries = traverseDir(childDocId, childRelPath, depth + 1)
                            if (subEntries == 0) {
                                // Empty subfolder: add explicit directory item so receiver recreates it
                                emptyFoldersCount++
                                transferItems.add(
                                    TransferFileItem(
                                        id = "${batchId}_dir_${transferItems.size}",
                                        name = safeName,
                                        sizeBytes = 0L,
                                        category = FileCategory.FOLDER,
                                        relativePath = childRelPath,
                                        rootFolderName = rootFolderName,
                                        folderBatchId = batchId,
                                        isDirectory = true,
                                        totalChunks = 1,
                                        sha256Expected = Sha256Util.EMPTY_DIR_SHA256
                                    )
                                )
                            }
                        } else {
                            var size = if (!c.isNull(sizeCol)) c.getLong(sizeCol).coerceAtLeast(0L) else 0L
                            val childUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, childDocId)
                            if (size == 0L) {
                                try {
                                    resolver.openAssetFileDescriptor(childUri, "r")?.use { afd ->
                                        if (afd.length > 0) size = afd.length
                                    }
                                } catch (_: Exception) {
                                }
                            }
                            val chunks = max(1, ((size + chunkSizeBytes - 1) / chunkSizeBytes).toInt())
                            val cat = FileCategory.fromFileName(safeName, mime)
                            totalFilesCount++
                            totalBytes += size

                            transferItems.add(
                                TransferFileItem(
                                    id = "${batchId}_f_${transferItems.size}",
                                    name = safeName,
                                    sizeBytes = size,
                                    category = cat,
                                    uri = childUri,
                                    relativePath = childRelPath,
                                    rootFolderName = rootFolderName,
                                    folderBatchId = batchId,
                                    isDirectory = false,
                                    totalChunks = chunks,
                                    sha256Expected = if (size == 0L) Sha256Util.EMPTY_BYTES_SHA256 else ""
                                )
                            )
                            previewItems.add(
                                DeviceMediaItem(
                                    id = "saf_${childUri.hashCode()}_${previewItems.size}",
                                    name = childRelPath,
                                    uri = childUri,
                                    sizeBytes = size,
                                    dateModifiedMillis = lastMod,
                                    mimeType = mime,
                                    bucketOrFolderName = rootFolderName,
                                    category = cat
                                )
                            )
                        }
                    }
                }
            } catch (_: SecurityException) {
                skippedUnreadableCount++
            } catch (_: Exception) {
                skippedUnreadableCount++
            }
            return entriesInThisDir
        }

        val rootEntries = traverseDir(rootDocId, rootFolderName, 0)
        if (rootEntries == 0 && skippedUnreadableCount > 0 && transferItems.isEmpty()) {
            return FolderScanResult(
                batchInfo = null,
                transferItems = emptyList(),
                previewMediaItems = emptyList(),
                errorMessage = "تعذر قراءة محتويات المجلد ($rootFolderName) لأن نظام Android يقيد الوصول إليه."
            )
        }

        // If the selected root folder itself is completely empty, still transfer it as an empty directory
        if (transferItems.isEmpty()) {
            emptyFoldersCount = 1
            transferItems.add(
                TransferFileItem(
                    id = "${batchId}_root_empty",
                    name = rootFolderName,
                    sizeBytes = 0L,
                    category = FileCategory.FOLDER,
                    relativePath = rootFolderName,
                    rootFolderName = rootFolderName,
                    folderBatchId = batchId,
                    isDirectory = true,
                    totalChunks = 1,
                    sha256Expected = Sha256Util.EMPTY_DIR_SHA256
                )
            )
        }

        val batchInfo = FolderBatchInfo(
            batchId = batchId,
            rootFolderName = rootFolderName,
            sourceUriOrPath = treeUri.toString(),
            totalFilesCount = totalFilesCount,
            totalSubfoldersCount = totalSubfoldersCount,
            emptyFoldersCount = emptyFoldersCount,
            totalBytes = totalBytes,
            skippedUnreadableCount = skippedUnreadableCount,
            hasPersistentPermission = hasPersistentPerm
        )

        return FolderScanResult(
            batchInfo = batchInfo,
            transferItems = transferItems,
            previewMediaItems = previewItems,
            errorMessage = null
        )
    }

    /**
     * Recursively scans a local java.io.File directory to send the entire folder as one unit,
     * preserving nested subfolders, relative paths, empty directories, and 0-byte files.
     */
    fun scanLocalFolderForTransfer(
        rootDir: File,
        chunkSizeBytes: Int
    ): FolderScanResult {
        if (!rootDir.exists() || !rootDir.isDirectory) {
            return FolderScanResult(
                batchInfo = null,
                transferItems = emptyList(),
                previewMediaItems = emptyList(),
                errorMessage = "المجلد المحدد غير موجود على الجهاز"
            )
        }
        if (!rootDir.canRead()) {
            return FolderScanResult(
                batchInfo = null,
                transferItems = emptyList(),
                previewMediaItems = emptyList(),
                errorMessage = "هذا المجلد (${rootDir.name}) محمي من نظام Android ولا يمكن قراءته بدون إذن خاص"
            )
        }

        val rootFolderName = sanitizePathSegment(rootDir.name.ifBlank { "Folder" })
        val batchId = "fld_${UUID.randomUUID().toString().take(8)}"
        val transferItems = mutableListOf<TransferFileItem>()
        val previewItems = mutableListOf<DeviceMediaItem>()
        var totalFilesCount = 0
        var totalSubfoldersCount = 0
        var emptyFoldersCount = 0
        var totalBytes = 0L
        var skippedUnreadableCount = 0

        fun traverseLocal(currentDir: File, currentRelPath: String, depth: Int): Int {
            if (depth > 24) return 0
            if (!currentDir.canRead()) {
                skippedUnreadableCount++
                return 0
            }
            val children = currentDir.listFiles()
            if (children == null) {
                skippedUnreadableCount++
                return 0
            }

            val sortedChildren = children.sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase(Locale.ROOT) }))
            val usedSiblingNames = HashSet<String>()
            var entriesInThisDir = 0

            for (child in sortedChildren) {
                val safeName = deduplicateSiblingName(sanitizePathSegment(child.name), usedSiblingNames)
                val childRelPath = "$currentRelPath/$safeName"
                entriesInThisDir++

                if (child.isDirectory) {
                    totalSubfoldersCount++
                    val subCount = traverseLocal(child, childRelPath, depth + 1)
                    if (subCount == 0) {
                        emptyFoldersCount++
                        transferItems.add(
                            TransferFileItem(
                                id = "${batchId}_dir_${transferItems.size}",
                                name = safeName,
                                sizeBytes = 0L,
                                category = FileCategory.FOLDER,
                                localFile = child,
                                relativePath = childRelPath,
                                rootFolderName = rootFolderName,
                                folderBatchId = batchId,
                                isDirectory = true,
                                totalChunks = 1,
                                sha256Expected = Sha256Util.EMPTY_DIR_SHA256
                            )
                        )
                    }
                } else if (child.isFile) {
                    if (!child.canRead()) {
                        skippedUnreadableCount++
                        continue
                    }
                    val size = child.length().coerceAtLeast(0L)
                    val chunks = max(1, ((size + chunkSizeBytes - 1) / chunkSizeBytes).toInt())
                    val cat = FileCategory.fromFileName(safeName)
                    totalFilesCount++
                    totalBytes += size

                    transferItems.add(
                        TransferFileItem(
                            id = "${batchId}_f_${transferItems.size}",
                            name = safeName,
                            sizeBytes = size,
                            category = cat,
                            localFile = child,
                            relativePath = childRelPath,
                            rootFolderName = rootFolderName,
                            folderBatchId = batchId,
                            isDirectory = false,
                            totalChunks = chunks,
                            sha256Expected = if (size == 0L) Sha256Util.EMPTY_BYTES_SHA256 else ""
                        )
                    )
                    previewItems.add(
                        DeviceMediaItem(
                            id = "local_${child.absolutePath.hashCode()}",
                            name = childRelPath,
                            localFile = child,
                            sizeBytes = size,
                            dateModifiedMillis = child.lastModified(),
                            bucketOrFolderName = rootFolderName,
                            category = cat
                        )
                    )
                }
            }
            return entriesInThisDir
        }

        traverseLocal(rootDir, rootFolderName, 0)

        if (transferItems.isEmpty()) {
            emptyFoldersCount = 1
            transferItems.add(
                TransferFileItem(
                    id = "${batchId}_root_empty",
                    name = rootFolderName,
                    sizeBytes = 0L,
                    category = FileCategory.FOLDER,
                    localFile = rootDir,
                    relativePath = rootFolderName,
                    rootFolderName = rootFolderName,
                    folderBatchId = batchId,
                    isDirectory = true,
                    totalChunks = 1,
                    sha256Expected = Sha256Util.EMPTY_DIR_SHA256
                )
            )
        }

        val batchInfo = FolderBatchInfo(
            batchId = batchId,
            rootFolderName = rootFolderName,
            sourceUriOrPath = rootDir.absolutePath,
            totalFilesCount = totalFilesCount,
            totalSubfoldersCount = totalSubfoldersCount,
            emptyFoldersCount = emptyFoldersCount,
            totalBytes = totalBytes,
            skippedUnreadableCount = skippedUnreadableCount,
            hasPersistentPermission = true
        )

        return FolderScanResult(
            batchInfo = batchInfo,
            transferItems = transferItems,
            previewMediaItems = previewItems,
            errorMessage = null
        )
    }

    private fun resolveTreeRootFolderName(
        resolver: ContentResolver,
        treeUri: Uri,
        rootDocId: String
    ): String {
        try {
            val docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, rootDocId)
            resolver.query(
                docUri,
                arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME),
                null,
                null,
                null
            )?.use { c ->
                if (c.moveToFirst()) {
                    val name = c.getString(0)
                    if (!name.isNullOrBlank()) return name
                }
            }
        } catch (_: Exception) {
        }
        val decoded = try {
            URLDecoder.decode(rootDocId, "UTF-8")
        } catch (_: Exception) {
            rootDocId
        }
        return decoded.substringAfterLast(':').substringAfterLast('/').ifBlank { "مجلد_مرسل" }
    }

    fun sanitizePathSegment(raw: String): String {
        val cleaned = raw.trim()
            .replace('\\', '_')
            .replace('/', '_')
            .replace(":", "_")
            .replace("*", "_")
            .replace("?", "_")
            .replace("\"", "_")
            .replace("<", "_")
            .replace(">", "_")
            .replace("|", "_")
        return if (cleaned.isBlank() || cleaned == "." || cleaned == "..") "مجلد" else cleaned
    }

    fun deduplicateSiblingName(baseName: String, usedNamesLower: MutableSet<String>): String {
        val lower = baseName.lowercase(Locale.ROOT)
        if (usedNamesLower.add(lower)) return baseName
        val dotIdx = baseName.lastIndexOf('.')
        val stem = if (dotIdx > 0) baseName.substring(0, dotIdx) else baseName
        val ext = if (dotIdx > 0) baseName.substring(dotIdx) else ""
        var counter = 1
        while (true) {
            val candidate = "$stem ($counter)$ext"
            if (usedNamesLower.add(candidate.lowercase(Locale.ROOT))) {
                return candidate
            }
            counter++
        }
    }

    /**
     * Reads files inside a user-picked SAF folder (OpenDocumentTree) for previewing in Files tab.
     */
    fun loadFilesFromDocumentTree(context: Context, treeUri: Uri): List<DeviceMediaItem> {
        return scanDocumentTreeForTransfer(context, treeUri, 1024 * 1024).previewMediaItems
    }

    private fun loadMediaThumbnail(
        resolver: ContentResolver,
        uri: Uri,
        mediaId: Long,
        isVideo: Boolean
    ): ImageBitmap? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                resolver.loadThumbnail(uri, Size(144, 144), null).asImageBitmap()
            } else {
                @Suppress("DEPRECATION")
                val bmp = if (isVideo) {
                    MediaStore.Video.Thumbnails.getThumbnail(
                        resolver,
                        mediaId,
                        MediaStore.Video.Thumbnails.MINI_KIND,
                        BitmapFactory.Options()
                    )
                } else {
                    MediaStore.Images.Thumbnails.getThumbnail(
                        resolver,
                        mediaId,
                        MediaStore.Images.Thumbnails.MINI_KIND,
                        BitmapFactory.Options()
                    )
                }
                bmp?.asImageBitmap()
            }
        } catch (_: Exception) {
            null
        }
    }
}
